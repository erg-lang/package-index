# poise

Ergパッケージマネージャ

このパッケージマネージャはergに同梱されており、`erg pack`サブコマンドで利用できます。コマンドの利用方法については[こちら](https://github.com/erg-lang/erg/blob/main/doc/JA/tools/pack.md)を参照してください。

## Requirements

* Git
* [Github CLI](https://cli.github.com/) (パッケージを公開したい場合)
